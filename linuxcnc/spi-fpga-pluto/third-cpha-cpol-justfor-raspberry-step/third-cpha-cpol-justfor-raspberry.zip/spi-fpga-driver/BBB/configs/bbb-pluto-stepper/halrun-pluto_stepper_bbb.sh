#!/bin/sh

halrun -I -f pluto_stepper_bbb_test2.hal
