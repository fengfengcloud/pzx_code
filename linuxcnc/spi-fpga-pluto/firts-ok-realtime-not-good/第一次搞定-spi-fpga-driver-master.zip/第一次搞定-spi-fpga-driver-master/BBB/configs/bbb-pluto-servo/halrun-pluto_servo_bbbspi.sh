#!/bin/sh

halrun -V -I -f pluto_servo_bbbspi.hal
