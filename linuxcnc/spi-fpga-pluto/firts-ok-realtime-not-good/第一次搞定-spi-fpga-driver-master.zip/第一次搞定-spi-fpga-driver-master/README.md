spi-fpga-driver
===============

LinuxCNC to fpga over spi driver for Beagleboneblack and RaspberryPi
for the Pluto-P Board 

(http://www.knjn.com/FPGA-Parallel.html).

Further Docs:

http://wiki.linuxcnc.org/cgi-bin/wiki.pl?RaspbianXenomaiBuild

http://www.raspberrypi.org/forums/viewtopic.php?f=37&t=33809

In the meantime parts of the raspi code flows to

"Driver for the Raspberry Pi and the Mesa 7i90HD Anything IO Card over SPI"

https://github.com/LinuxCNC/linuxcnc/pull/107
