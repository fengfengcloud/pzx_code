#define XENOMAI_INCLUDE(header) <XENOMAI_SKIN/header>
