These directories are for compiling outside the linuxcnc or machinekit source tree.

So it works with "halcomp --install hm2_rpspi.c" in linuxcnc or "comp --install hm2_rpspi.c" in machinekit, respectively.
Just with linuxcnc and linuxcnc-dev packages or machinekit and machinekit-dev packages, respectively.

But they are just snapshots it has to be adjusted in case of outside updates.


