halcompile --install pluto_step_rpspi.c
