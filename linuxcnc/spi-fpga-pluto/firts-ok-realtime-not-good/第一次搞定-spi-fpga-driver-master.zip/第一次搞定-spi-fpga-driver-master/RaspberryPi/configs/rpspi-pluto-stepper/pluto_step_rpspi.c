# This config file was created 2019-10-23 15:53:02.720280 by the update_ini script
# The original config files may be found in the /home/pi/spi-fpga-driver-master/RaspberryPi/configs/rpspi-pluto-stepper/pluto_step_rpspi.old directory

