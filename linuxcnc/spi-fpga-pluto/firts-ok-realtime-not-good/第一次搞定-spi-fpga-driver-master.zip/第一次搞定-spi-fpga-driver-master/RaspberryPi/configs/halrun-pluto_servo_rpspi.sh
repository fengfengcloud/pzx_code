#!/bin/sh

halrun -I -f pluto_servo_rpspi.hal
