It has to be called with "machinekit pluto_inch.ini".
